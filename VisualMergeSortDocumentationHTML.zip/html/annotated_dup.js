var annotated_dup =
[
    [ "NaturalMergeSortVisual", null, [
      [ "NaturalMerge", "class_natural_merge_sort_visual_1_1_natural_merge.html", "class_natural_merge_sort_visual_1_1_natural_merge" ]
    ] ]
];