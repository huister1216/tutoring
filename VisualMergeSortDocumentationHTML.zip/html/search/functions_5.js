var searchData=
[
  ['printmetrics_16',['printMetrics',['../class_natural_merge_sort_visual_1_1_natural_merge.html#a9b808cb10f64998c47c6de6d6a2302a4',1,'NaturalMergeSortVisual::NaturalMerge']]]
];
